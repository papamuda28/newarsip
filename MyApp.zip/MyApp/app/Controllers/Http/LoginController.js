'use strict'

class LoginController {
     signin ({view})  {
        return view.render('/login')
    }
     async login ({request, auth, response}) {
        const {username, password} = request.all()
        await auth.attempt(username, password)
        return response.route('/index')
    }
}

module.exports = LoginController
