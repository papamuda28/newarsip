'use strict'
const User = use('App/Models/Index')
class IndexController {
    async store ({ request, response}) {
        const user = new User()
        user.email= request.input('email'),
        await user.save()
        return response.redirect('/index')
    }
}


module.exports = IndexController
