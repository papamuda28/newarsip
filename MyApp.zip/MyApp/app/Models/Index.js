'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class Index extends Model {
    static get email() {return 'email'}
}

module.exports = Index
